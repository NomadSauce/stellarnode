# Javascript SDK for Telegram Passport

More info about [Telegram Passport](https://core.telegram.org/passport)

[Telegram Passport announcement](https://telegram.org/blog/passport)
